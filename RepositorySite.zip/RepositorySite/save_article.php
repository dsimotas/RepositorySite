<?php


session_start();

session_set_cookie_params([
    'httponly' => true,
    'secure' => true,
    'samesite' => 'Strict'
]);
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $category = htmlspecialchars(strip_tags($_POST['category']));
    $title = htmlspecialchars(strip_tags($_POST['title']));
    $content = htmlspecialchars($_POST['content'], ENT_QUOTES, 'UTF-8');

    $directory = "articles/$category";
    if (!file_exists($directory)) {
        mkdir($directory, 0777, true);
    }

    $filename = $directory . '/' . preg_replace("/[^a-zA-Z0-9]+/", "-", strtolower($title)) . "_" . time() . ".php";

    $articleContent = "
    <?php
    session_start();
    if (!isset(\$_SESSION['loggedin']) || \$_SESSION['loggedin'] !== true) {
        header('Location: ../../login.php');
        exit();
    }
    ?>
    <!DOCTYPE html>
    <html lang=\"en\">
    <head>
        <meta charset=\"UTF-8\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
        <title>$title</title>
        <link rel=\"stylesheet\" href=\"../css/style.css\">
        <style>
            body {
                font-family: 'Arial', sans-serif;
                line-height: 1.6;
                color: #333;
                margin: 0;
                padding: 20px;
                background-color: #f5f6fa;
            }
            .container {
                max-width: 800px;
                margin: 0 auto;
                background-color: #ffffff;
                border-radius: 10px;
                box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
                padding: 30px;
            }
            .form-section h2 {
                color: #2f3640;
                border-bottom: 2px solid #2f3640;
                padding-bottom: 10px;
                margin-bottom: 20px;
            }
            .article-content {
                font-size: 20px;
                color: #353b48;
                margin-bottom: 30px;
            }
            .back-link {
                display: inline-block;
                margin-top: 20px;
                padding: 10px 15px;
                background-color: #2980b9;
                color: #fff;
                text-decoration: none;
                border-radius: 5px;
                transition: background-color 0.3s ease;
            }
            .back-link:hover {
                background-color: #3498db;
            }
        </style>
    </head>
    <body>
        <div class=\"container\">
            <div class=\"form-section\">
                <h2>$title</h2>
                <div class=\"article-content\">$content</div>
            </div>
            <div class=\"articles-section\">
                <a href=\"/RepositorySite/index.php\" class=\"back-link\">Back to Home</a>
            </div>
        </div>
    </body>
    </html>";

    file_put_contents($filename, $articleContent);
    header("Location: index.php");
    exit();
}
?>
