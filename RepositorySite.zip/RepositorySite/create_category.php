<?php

session_start();

session_set_cookie_params([
    'httponly' => true,
    'secure' => true,
    'samesite' => 'Strict'
]);
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php');
    exit();
}

$category = trim($_POST['category']);
$file = 'categories.json';
$articlesDir = 'articles';

if (!empty($category)) {

    if (!file_exists($articlesDir)) {
        mkdir($articlesDir, 0777, true);
    }


    $categoryPath = "$articlesDir/$category";
    if (!file_exists($categoryPath)) {
        mkdir($categoryPath, 0777, true);
    }

    $categories = file_exists($file) ? json_decode(file_get_contents($file), true) : [];
    if (!in_array($category, $categories)) {
        $categories[] = $category;
        sort($categories);
        file_put_contents($file, json_encode($categories));
        echo "Category '$category' created successfully.";
    } else {
        echo "Category '$category' already exists.";
    }
} else {
    echo "Invalid category name.";
}
?>
