<?php

session_start();

session_set_cookie_params([
    'httponly' => true,
    'secure' => true,
    'samesite' => 'Strict'
]);
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php');
    exit();
}



$file = 'categories.json';
if (file_exists($file)) {
    $categories = json_decode(file_get_contents($file), true);
    echo json_encode($categories);
} else {
    echo json_encode([]);
}
?>
