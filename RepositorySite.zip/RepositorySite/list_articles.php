<?php

session_start();
session_set_cookie_params([
    'httponly' => true,
    'secure' => true,
    'samesite' => 'Strict'
]);
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php');
    exit();
}

$articles = [];


$iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator('articles'));

foreach ($iterator as $file) {
    if ($file->isFile() && $file->getExtension() === 'php') {
        $filename = $file->getFilename();
        $filepath = $file->getPathname();
        $title = 'Untitled';

        ob_start();
        include $filepath;
        $content = ob_get_clean();

        if (preg_match('/<title>(.*?)<\/title>/', $content, $matches)) {
            $title = htmlspecialchars($matches[1], ENT_QUOTES, 'UTF-8');
        }

        $articles[] = [
            'filename' => str_replace('articles/', '', $filepath),
            'title' => $title,
            'date' => date('Y-m-d H:i:s', $file->getMTime())
        ];
    }
}

usort($articles, function ($a, $b) {
    return strtotime($b['date']) - strtotime($a['date']);
});


$articles = array_slice($articles, 0, 3);

header('Content-Type: application/json');
echo json_encode($articles);
?>
