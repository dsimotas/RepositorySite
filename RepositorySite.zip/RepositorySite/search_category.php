<?php

session_start();
session_set_cookie_params([
    'httponly' => true,
    'secure' => true,
    'samesite' => 'Strict'
]);
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php');
    exit();
}

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


function getCategoryArticles($dir) {
    $files = [];
    if (is_dir($dir)) {
        foreach (scandir($dir) as $item) {
            if ($item === '.' || $item === '..') continue;
            $path = "$dir/$item";
            if (is_file($path) && pathinfo($path, PATHINFO_EXTENSION) === 'php') {
                $files[] = $path;
            }
        }
    }
    return $files;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Category Search Results</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <div class="title">Category Search Results</div>

        <div class="articles-section">
            <?php
            if (isset($_GET['category'])) {
                $category = basename($_GET['category']);
                $directory = "articles/$category";
                $files = getCategoryArticles($directory);
                $results = [];

                foreach ($files as $file) {
                    $content = file_get_contents($file);


                    if (preg_match('/<title>(.*?)<\/title>/', $content, $matches)) {
                        $title = $matches[1];
                    } else {
                        $title = basename($file);
                    }

                    $relativePath = str_replace('articles/', '', $file);

                    $results[] = [
                        'filename' => $relativePath,
                        'title' => $title
                    ];
                }

                if (!empty($results)) {
                    echo "<h2>Articles in Category: " . htmlspecialchars($category) . "</h2>";
                    foreach ($results as $result) {
                        echo "<div class='article'>
                                <h3>{$result['title']}</h3>
                                <a href='articles/{$result['filename']}' target='_blank'>Read More</a>
                              </div>";
                    }
                } else {
                    echo "<p>No articles found in this category.</p>";
                }
            } else {
                echo "<p>No category specified.</p>";
            }
            ?>
        </div>

        <div class="form-section">
            <a href="index.php" class="back-link">Back to Home</a>
        </div>
    </div>
</body>
</html>
