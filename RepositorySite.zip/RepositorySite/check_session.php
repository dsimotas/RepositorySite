<?php
session_start();




$response = [
    'loggedin' => isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true
];

header('Content-Type: application/json');
echo json_encode($response);
?>
