<?php


session_start();

session_set_cookie_params([
    'httponly' => true,
    'secure' => true,
    'samesite' => 'Strict'
]);
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php');
    exit();
}

?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Article Repository</title>
    <link rel="stylesheet" href="css/style.css">
    <script>

        document.addEventListener('DOMContentLoaded', () => {
            fetch('check_session.php', {credentials: 'same-origin'})
                .then(response => response.json())
                .then(data => {
                    if (!data.loggedin) {
                        window.location.href = 'login.php';
                    } else {
                        document.getElementById('mainContent').style.display = 'flex';
                    }
                })
                .catch(error => {
                    console.error('Error checking session:', error);
                    window.location.href = 'login.php';
                });


            fetch('list_categories.php', {credentials: 'same-origin'})
                .then(response => response.json())
                .then(categories => {
                    const list = document.querySelector('.category-list');
                    const dropdown = document.getElementById('categoryDropdown');
                    list.innerHTML = '';
                    dropdown.innerHTML = '<option value="">Select Category</option>';

                    if (categories && categories.length > 0) {
                        categories.forEach(category => {

                            const li = document.createElement('li');
                            li.textContent = category;
                            li.style.cursor = 'pointer';
                            li.onclick = () => {
                                window.location.href = `search_category.php?category=${encodeURIComponent(category)}`;
                            };
                            list.appendChild(li);


                            const option = document.createElement('option');
                            option.value = category;
                            option.textContent = category;
                            dropdown.appendChild(option);
                        });
                    } else {
                        const li = document.createElement('li');
                        li.textContent = 'No categories found';
                        list.appendChild(li);
                    }
                })
                .catch(error => {
                    console.error('Error loading categories:', error);
                    const list = document.querySelector('.category-list');
                    list.innerHTML = '<li>Error loading categories</li>';
                });
        });

        function addCategory() {
            const categoryInput = document.getElementById('newCategory');
            const category = categoryInput.value.trim();
            if (category && category.length <= 40) {
                fetch('create_category.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: 'category=' + encodeURIComponent(category),
                    credentials: 'same-origin'
                })
                .then(response => response.text())
                .then(result => {
                    alert(result);
                    categoryInput.value = '';

                    fetch('list_categories.php', {credentials: 'same-origin'})
                        .then(response => response.json())
                        .then(categories => {
                            const list = document.querySelector('.category-list');
                            list.innerHTML = '';
                            categories.forEach(category => {
                                const li = document.createElement('li');
                                li.textContent = category;
                                li.style.cursor = 'pointer';
                                li.onclick = () => {
                                    window.location.href = `search_category.php?category=${encodeURIComponent(category)}`;
                                };
                                list.appendChild(li);
                            });
                        })
                        .catch(error => {
                            console.error('Error reloading categories:', error);
                        });
                })
                .catch(error => alert('Error: ' + error));
            } else {
                alert('Please enter a valid category name with a maximum of 40 characters.');
            }
        }

        function updateHiddenContent() {
            const contentDiv = document.getElementById('contentEditable').innerHTML;
            const sanitizedContent = contentDiv.replace(/<script.*?>.*?<\/script>/gi, '');
            document.getElementById('hiddenContent').value = sanitizedContent;
        }
    </script>
    <style>
body {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
    box-sizing: border-box;
    width: 100%;
    font-size: 1rem;
}
.main-container {
    display: flex;
    width: 100%;
    height: 100%;
}
.sidebar {
    width: 15vw;
    height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    border-right: 0.1rem solid #ccc;
    padding: 2vh 2vw;
    box-sizing: border-box;
    position: fixed;
    left: 0;
    top: 0;
}
.sidebar .title {
    font-size: 2vw;
    margin-bottom: 2vh;
    text-align: left;
}
.sidebar .category-section {
    margin-top: 2vh;
    width: 100%;
}
.sidebar .category-section h3 {
    margin-bottom: 1vh;
    font-size: 1.2rem;
}
.sidebar .category-section input {
    width: 100%;
    padding: 0.5rem;
    margin-bottom: 1rem;
    border: 0.1rem solid #ccc;
    border-radius: 0.5rem;
    box-sizing: border-box;
}
.sidebar .category-list {
    margin-top: 1vh;
    list-style: none;
    padding: 0;
}
.sidebar .category-list li {
    margin: 0.5vh 0;
    font-size: 1rem;
    cursor: pointer;
    color: blue;
    text-decoration: underline;
}
.sidebar .logout-section {
    margin-top: auto;
    text-align: left;
}
.sidebar a {
    text-decoration: none;
    color: inherit;
    display: block;
    margin: 1vh 0;
    font-size: 1.2rem;
}
.content {
    margin-left: 16vw;
    padding: 2vh 5vw;
    box-sizing: border-box;
    width: calc(100vw - 20vw);
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: flex-start;
    height: 100vh;
}
.content .search-section, .content .form-section, .content .articles-section {
    width: 100%;
    text-align: center;
    margin: 0vh 0;
    padding: 0vh 0vw;
    box-sizing: border-box;
    flex: 0 0 auto;
    max-width: 100%;
}
.content input[type="text"], .content textarea, .content button, #contentEditable {
    width: 100%;
    box-sizing: border-box;
    margin: 1vh 0;
    padding: 1vh 1vw;
    font-size: 1rem;
    border: 0.1rem solid #ccc;
    border-radius: 0.5rem;
}
#contentEditable {
    background-color: #fff;
    min-height: 15vh;
}
.content h2 {
    margin-bottom: 1vh;
    font-size: 1.5rem;
}
.article {
    padding: 1vh 1vw;
    margin: 1vh 0;
    border: 0.1rem solid #ccc;
    border-radius: 0.5rem;
    text-align: center;
    font-size: 1rem;
}
    </style>
</head>
<body>
    <div id="mainContent">
        <div class="main-container">

            <div class="sidebar">
                <div class="title">Document Repository</div>
                <div class="category-section">
                    <h3>New Category</h3>
                    <form action="create_category.php" method="post">
                        <input type="text" name="category" id="newCategory" placeholder="Enter category name (max 40 chars)" maxlength="40" required>
                        <button type="button" onclick="addCategory()">Add Category</button>
                    </form>
                    <h3>Categories</h3>
                    <ul class="category-list">Loading categories...</ul>
                </div>
                <div class="logout-section">
                    <a href="logout.php">Logout</a>
                </div>
            </div>

            <div class="content">
 
                <div class="search-section">
                    <h2>Search For Articles</h2>
                    <form action="search_articles.php" method="get">
                        <input type="text" name="query" placeholder="Search articles based on keyword..." required>
                        <button type="submit">Search</button>
                    </form>
                </div>
                <div class="form-section">
                    <h2>Create A New Article</h2>
                    <form id="articleForm" action="save_article.php" method="post" onsubmit="return validateForm()">

                        <label for="categoryDropdown">Select Category:</label>
                        <select name="category" id="categoryDropdown" required>
                            <option value="">Select Category</option>
                        </select>
                        <input type="text" name="title" placeholder="Article Title" required>
                        <div id="contentEditable" contenteditable="true" style="border: 1px solid #ccc; min-height: 150px; background-color: #fff;" required></div>
                        <textarea name="content" id="hiddenContent" style="display:none;" required></textarea>
                        <button type="submit" onclick="updateHiddenContent()">Add Article</button>
                    </form>
                </div>
                <div class="articles-section">
                    <h2>Recent Articles</h2>
                    <div id="articles"></div>
                </div>
            </div>
        </div>
    </div>
    <script>

        fetch('list_articles.php')
            .then(response => response.json())
            .then(articles => {
                const container = document.getElementById('articles');
                if (articles.length > 0) {
                    articles.forEach(article => {
                        const div = document.createElement('div');
                        div.className = 'article';
                        div.innerHTML = div.innerHTML = `<h3>${article.title}</h3><a href='articles/${article.filename}' target='_blank'>Read More</a>`;

                        container.appendChild(div);
                    });
                } else {
                    container.innerHTML = '<p>No articles found.</p>';
                }
            })
            .catch(error => console.error('Error loading articles:', error));
    </script>
</body>
</html>
